## ----setup, include=FALSE, cache=FALSE-----------------------------------
library(knitr)
opts_chunk$set(fig.pos='H', comment=NA)

## ----install1, eval=FALSE------------------------------------------------
#  install.packages('devtools')
#  library(devtools)

## ----install2, eval=FALSE------------------------------------------------
#  install_github('UCL/GammaModel')
#  library(GammaModel)
#  help(GammaModel)

## ----data1, eval=TRUE----------------------------------------------------
library(GammaModel)
data(Neolithic)
print(Neolithic)

## ----data2, eval=FALSE---------------------------------------------------
#  help(Neolithic)

## ----data3, eval=TRUE----------------------------------------------------
library(GammaModel)
data(Neolithic)
counts <- Neolithic['PPI',]
aa <- allArrangements(counts)
print(aa)

## ----data4, eval=TRUE----------------------------------------------------
library(GammaModel)
data(Neolithic)
counts <- Neolithic['TRA2',]
x <- allArrangements(counts) 
print(counts)
print(nrow(x))

## ----gof1, echo=FALSE, eval=TRUE-----------------------------------------
tab <- data.frame(Class=LETTERS[1:9],
	age=c('0 to 2 months',
		'2 to 6 months',
		'6 to 12 months',
		'1 to 2 years',
		'2 to 3 years',
		'3 to 4 years',
		'4 to 6 years',
		'6 to 8 years',
		'8 years or more'))
print(tab, row.names=F)

## ----gof2, eval=TRUE-----------------------------------------------------
# payne models
data(models.payne)
print(models.payne)

# redding models
data(models.redding)
print(models.redding)

## ----gof3, eval=FALSE----------------------------------------------------
#  help(models.payne)
#  help(models.redding)

## ----gof4, eval=FALSE----------------------------------------------------
#  data(Neolithic)
#  data(models.payne)
#  counts <- Neolithic['FON1',]
#  model <- models.payne['meat',]
#  GOF(counts, model)

## ----gof5, eval=FALSE----------------------------------------------------
#  GOF(counts, model, N = 20000)

## ----acml1, eval=TRUE----------------------------------------------------
data(Neolithic)
counts <- Neolithic['TRA1',]
MLpar <- ageClassMLparameters(counts)
MLE <- ageClassLogMLE(counts)
print(counts) # raw data
print(MLpar) # most likely model parameters (probabilities)
print(MLE) # log maximum likelihood estimate

## ----gml1,eval=TRUE,cache=TRUE-------------------------------------------
data(Neolithic)
counts <- Neolithic['TRA1',]
MLpar <- gammaMLparameters(counts)
MLE <- gammaLogMLE(counts)
print(MLpar) # most likely model parameters
print(MLE) # log maximum likelihood estimate

# find ML parameters for three datasets
p1 <- gammaMLparameters(Neolithic['TRA1',])
p2 <- gammaMLparameters(Neolithic['TES',])
p3 <- gammaMLparameters(Neolithic['WIK',])

## ----gml2,eval=TRUE,cache=TRUE,dependson='gml1',fig.width=6,fig.height=4----

# x-axis to cover 10 years
x <- seq(0,10,length.out=1000) 

# full Gamma distributions
y1 <- dgamma(x, p1$shape, p1$shape/p1$mean)
y2 <- dgamma(x, p2$shape, p2$shape/p2$mean)
y3 <- dgamma(x, p3$shape, p3$shape/p3$mean)

plot(NULL,xlim=c(0,10),ylim=c(0,0.4),xlab='age', ylab='probability density')
lines(x,y1,col=1,lwd=2)
lines(x,y2,col=2,lwd=2)
lines(x,y3,col=3,lwd=2)

# legend
legend(x=8, y=0.3, bty='n', col=1:3, lwd=2, legend= c('TRA1','TES','WIK'))

## ----mcmc1,eval=TRUE,cache=TRUE------------------------------------------
data(Neolithic) # load data
counts <- Neolithic['TRA1',]
pars <- mcmc(counts) # generate a MCMC chain

## ----mcmc2,eval=TRUE,cache=TRUE,dependson='mcmc1',fig.width=5,fig.height=5----

# plot the MCMC chain output
plot(pars, pch='+', cex = 0.5)

# Add contour lines by first generating 2D kernels
# Requires the ks package
library(ks) 
H <- matrix(c(0.012, 0, 0, 0.012), 2, 2)
fhat <- kde(x=pars, H=H)
plot(fhat, drawlabels=T, lwd=2, lty=1, add=T, col='red')

## ----mcmc3,eval=TRUE,cache=TRUE,dependson='mcmc1',fig.width=6,fig.height=4----
# calculate the 'rate' parameter for each sample
pars$rate <- pars$shape / pars$mean

# generate an age range of interest
x <- seq(0,5,length.out=1000)

# start with a blank plot
plot(NULL, xlim=c(0,5), ylim=c(0,0.5), xlab='age', ylab='PD', main='TRA1')

# add 2000 samples from the chain
library(scales) # alpha function for transparency 
for(n in 1:2000){
	y <- dgamma(x, shape=pars$shape[n], rate=pars$rate[n])
	lines(x,y,col=alpha('black',alpha=0.04))
	}

## ----mcmc4,eval=TRUE,cache=TRUE,dependson='mcmc1'------------------------
#------------------------------------------------------------
# mean slaughter age
#------------------------------------------------------------
# Maximum Likelihood
MLpar$mean

#95% CI
quantile(pars$mean, c(0.025, 0.975))

#------------------------------------------------------------
# mode slaughter age (peak / most common)
#------------------------------------------------------------
# Maximum Likelihood
mode <- (MLpar$shape - 1) * (MLpar$mean / MLpar$shape)

# constrain to age zero
if(mode < 0) mode <- 0
print(mode)

# 95% CI
# first calculate the mode for each sample of the chain
pars$mode <- (pars$shape - 1) * (pars$mean / pars$shape)

# constrain to age zero
pars$mode[pars$mode < 0] <- 0 

# finally the 95% HDI
library(LaplacesDemon)
p.interval(pars$mode, prob = 0.95)

#------------------------------------------------------------
# Age range covering the majority of slaughters
#------------------------------------------------------------
# rgamma() requires shape and rate parameters
MLpar$rate <- MLpar$shape / MLpar$mean

# generate random samples from the distribution
rg <- rgamma(1000000, shape = MLpar$shape, rate = MLpar$rate)

# find the 50% HDI range
p.interval(rg, prob = 0.5)

